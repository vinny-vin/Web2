/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifpe.recife.model.repositorios;

import br.edu.ifpe.recife.model.negocio.Campanha;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author vibefer
 */
public class RepositorioCampanha {
    
    public static List<Campanha> campanhas = null;
    
    static {
        campanhas = new ArrayList<>();
    }
    
    public static void create(Campanha o){
        campanhas.add(o);
    }
    
    public static void update(Campanha o){
        
        for (Campanha oAux : campanhas) {
            if (oAux.getCodigo() == o.getCodigo()) {
                oAux.setCodigo(o.getCodigo());
                oAux.setDataInicio(o.getDataInicio());
                oAux.setDataFim(o.getDataFim());
                oAux.setObjetivo(o.getObjetivo());
                oAux.setDescricao(o.getDescricao());
                
                return;
            }
        }
        
    }
    
    public static Campanha read(int codigo){
        
        for(Campanha oAux: campanhas){
            if(oAux.getCodigo()==codigo){
                return oAux;
            }
        }
        return null;
    }
    
    public static void delete(Campanha o){
        campanhas.remove(o);
    }
    
    public static List<Campanha> readAll(){
        return campanhas;
    }
}
