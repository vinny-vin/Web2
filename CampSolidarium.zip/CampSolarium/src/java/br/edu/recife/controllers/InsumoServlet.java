/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.recife.controllers;

import br.edu.ifpe.recife.model.negocio.Insumo;
import br.edu.ifpe.recife.model.repositorios.RepositorioInsumo;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "InsumoServlet", urlPatterns = {"/InsumoServlet"})
public class InsumoServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet InsumoServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet InsumoServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String codigoParam = request.getParameter("codigo");

        if (codigoParam != null && !codigoParam.isEmpty()) {
            try {
                int codigo = Integer.parseInt(codigoParam);
                Insumo insumo = RepositorioInsumo.read(codigo);
                if (insumo != null) {
                    String operacao = request.getParameter("operacao");

                    if ("edit".equals(operacao)) {
                        response.setContentType("text/html;charset=UTF-8");
                        try (PrintWriter out = response.getWriter()) {
                            out.println("<!DOCTYPE html>");
                            out.println("<html>");
                            out.println("<head>");
                            out.println("<title>Editar Insumo</title>");
                            out.println("</head>");
                            out.println("<body>");
                            out.println("<h1>Editar Insumo: " + insumo.getNome() + "</h1>");
                            out.println("<form method='post' action='InsumoServlet'>");
                            out.println("<input type='hidden' name='codigo' value='" + insumo.getCodigo() + "'/></br>");
                            out.println("Nome: <input type='text' name='nome' value='" + insumo.getNome() + "'/></br>");
                            out.println("Marca: <input type='text' name='marca' value='" + insumo.getMarca() + "'/></br>");
                            out.println("Categoria: <input type='text' name='categoria' value='" + insumo.getCategoria() + "'/></br>");
                            out.println("<input type='submit' value='Editar'/></br>");
                            out.println("</form>");
                            out.println("<a href='InsumoServlet'>Voltar</a>");
                            out.println("</body>");
                            out.println("</html>");
                        }
                    } else if ("delete".equals(operacao)) {
                        RepositorioInsumo.delete(insumo);
                        response.setContentType("text/html;charset=UTF-8");
                        try (PrintWriter out = response.getWriter()) {
                            out.println("<!DOCTYPE html>");
                            out.println("<html>");
                            out.println("<head>");
                            out.println("<title>Excluir Insumo</title>");
                            out.println("</head>");
                            out.println("<body>");
                            out.println("<h1>Insumo Excluído com Sucesso!</h1>");
                            out.println("<a href='InsumoServlet'>Voltar</a>");
                            out.println("</body>");
                            out.println("</html>");
                        }
                    } else {
                        response.setContentType("text/html;charset=UTF-8");
                        try (PrintWriter out = response.getWriter()) {
                            out.println("<!DOCTYPE html>");
                            out.println("<html>");
                            out.println("<head>");
                            out.println("<title>Detalhes do Insumo</title>");
                            out.println("</head>");
                            out.println("<body>");
                            out.println("<h1>Detalhes do Insumo: " + insumo.getNome() + "</h1>");
                            out.println("<h5>Marca: " + insumo.getMarca() + "</h5>");
                            out.println("<h5>Categoria: " + insumo.getCategoria() + "</h5>");
                            out.println("<a href='InsumoServlet'>Voltar</a>");
                            out.println("</body>");
                            out.println("</html>");
                        }
                    }
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Insumo não encontrado");
                }
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Código de Insumo inválido");
            }
        } else {
            List<Insumo> insumos = RepositorioInsumo.readAll();
            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Insumos Cadastrados</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Insumos Cadastrados</h1>");
                out.println("<a href='index.html'>Home</a>");
                out.println("<table border='1'>");
                out.println("<tr><th>Código</th><th>Nome</th><th>Marca</th><th>Categoria</th><th>Ações</th></tr>");
                for (Insumo insumo : insumos) {
                    out.println("<tr>");
                    out.println("<td>" + insumo.getCodigo() + "</td>");
                    out.println("<td>" + insumo.getNome() + "</td>");
                    out.println("<td>" + insumo.getMarca() + "</td>");
                    out.println("<td>" + insumo.getCategoria() + "</td>");
                    out.println("<td><a href='InsumoServlet?codigo=" + insumo.getCodigo() + "'>Detalhar</a> "
                            + "<a href='InsumoServlet?codigo=" + insumo.getCodigo() + "&operacao=edit'>Editar</a> "
                            + "<a href='InsumoServlet?codigo=" + insumo.getCodigo() + "&operacao=delete'>Excluir</a></td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String codigoParam = request.getParameter("codigo");

        if (codigoParam != null && !codigoParam.isEmpty()) {
            try {
                int codigo = Integer.parseInt(codigoParam);
                Insumo insumo = RepositorioInsumo.read(codigo);

                if (insumo != null) {
                    insumo.setNome(request.getParameter("nome"));
                    insumo.setMarca(request.getParameter("marca"));
                    insumo.setCategoria(request.getParameter("categoria"));

                    RepositorioInsumo.update(insumo);

                    response.setContentType("text/html;charset=UTF-8");
                    try (PrintWriter out = response.getWriter()) {
                        out.println("<!DOCTYPE html>");
                        out.println("<html>");
                        out.println("<head>");
                        out.println("<title>Insumo Atualizado</title>");
                        out.println("</head>");
                        out.println("<body>");
                        out.println("<h1>Insumo Atualizado com Sucesso!</h1>");
                        out.println("<a href='InsumoServlet'>Voltar</a>");
                        out.println("</body>");
                        out.println("</html>");
                    }
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND, "Insumo não encontrado");
                }
            } catch (NumberFormatException e) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Código de Insumo inválido");
            }
        } else {
            String nome = request.getParameter("nome");
            String marca = request.getParameter("marca");
            String categoria = request.getParameter("categoria");

            Insumo insumo = new Insumo(nome, marca, categoria);
            RepositorioInsumo.create(insumo);

            response.setContentType("text/html;charset=UTF-8");
            try (PrintWriter out = response.getWriter()) {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Insumo Cadastrado</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1>Insumo Cadastrado com Sucesso!</h1>");
                out.println("<a href='InsumoServlet'>Voltar</a>");
                out.println("</body>");
                out.println("</html>");
            }
        }
    }

    @Override
    public String getServletInfo() {
        return "InsumoServlet";
    }
}



