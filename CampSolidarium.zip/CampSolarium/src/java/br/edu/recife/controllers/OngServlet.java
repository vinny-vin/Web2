/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.recife.controllers;

import br.edu.ifpe.recife.model.negocio.Ong;
import br.edu.ifpe.recife.model.repositorios.RepositorioOng;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "OngServlet", urlPatterns = {"/OngServlet"})
public class OngServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use the following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet OngServlet</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet OngServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String codigo = request.getParameter("codigo");

        if (codigo != null && !codigo.isEmpty()) {
            try {
                int ongCodigo = Integer.parseInt(codigo);
                Ong ong = RepositorioOng.read(ongCodigo);
                if (ong != null) {
                    String operacao = request.getParameter("operacao");

                    if ("edit".equals(operacao)) {
                        response.setContentType("text/html;charset=UTF-8");
                        try (PrintWriter out = response.getWriter()) {
                            out.println("<!DOCTYPE html>");
                            out.println("<html>");
                            out.println("<head>");
                            out.println("<title>Editar Ong: " + ong.getNome() + "</title>");
                            out.println("</head>");
                            out.println("<body>");
                            out.println("<h1>Editar Ong: " + ong.getNome() + "</h1>");

                            out.println("<form method='post' action='OngServlet'>");
                            out.println("<input type='hidden' name='codigo' value='" + ong.getCodigo() + "'/></br>");
                            out.println("Nome:<input type='text' name='nome' value='" + ong.getNome() + "'/></br>");
                            out.println("Login:<input type='text' name='login' value='" + ong.getLogin() + "'/></br>");
                            out.println("Senha:<input type='password' name='senha' value='" + ong.getSenha() + "'/></br>");
                            out.println("Público:<input type='text' name='publico' value='" + ong.getPublico() + "'/></br>");
                            out.println("<input type='submit' value='editar'/></br>");
                            out.println("</form>");

                            out.println("<a href='OngServlet'>Voltar</a>");
                            out.println("</body>");
                            out.println("</html>");
                        }
                        return;
                    }
                }
            } catch (NumberFormatException e) {
                // Tratamento para evitar NumberFormatException
            }
        }

        List<Ong> ongs = RepositorioOng.readAll();

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Lista de Ongs</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Ongs Cadastradas</h1>");
            out.println("<a href='index.html'>Home</a>");
            out.println("<table border='1'>");
            out.println("<tr><th>Código</th><th>Nome</th><th>Login</th><th>Público</th><th>Ações</th></tr>");

            for (Ong ong : ongs) {
                out.println("<tr>");
                out.println("<td>" + ong.getCodigo() + "</td>");
                out.println("<td>" + ong.getNome() + "</td>");
                out.println("<td>" + ong.getLogin() + "</td>");
                out.println("<td>" + ong.getPublico() + "</td>");
                out.println("<td><a href='OngServlet?codigo=" + ong.getCodigo() + "'>Detalhar</a> "
                        + "<a href='OngServlet?codigo=" + ong.getCodigo() + "&operacao=edit'>Editar</a></td>");
                out.println("</tr>");
            }

            out.println("</table>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int codigo = 0;
        String codigoParam = request.getParameter("codigo");
        if (codigoParam != null && !codigoParam.isEmpty()) {
            try {
                codigo = Integer.parseInt(codigoParam);
            } catch (NumberFormatException e) {
               
            }
        }

        String nome = request.getParameter("nome");
        String login = request.getParameter("login");
        String senha = request.getParameter("senha");
        String publico = request.getParameter("publico");

        Ong ong = new Ong();
        ong.setCodigo(codigo);
        ong.setNome(nome);
        ong.setLogin(login);
        ong.setSenha(senha);
        ong.setPublico(publico);

        RepositorioOng.create(ong);

        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Resultado da Operação</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Ong cadastrada com sucesso!</h1>");
            out.println("<a href='OngServlet'>Voltar</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}



